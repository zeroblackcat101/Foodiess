package ae.ac.adu.joe.loginandregister.Activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Arrays;

import ae.ac.adu.joe.loginandregister.R;
import apis.RecipeApi;
import utils.CustomTask;
import utils.CustomTaskResult;

public class dummyCreateRecipe extends AppCompatActivity {
  Button postImg;
    Uri imgUri = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy_create_recipe);
        postImg = findViewById(R.id.postBtn);

        setUpPopupImgClick();

    }


    private void setUpPopupImgClick() {
        ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
                uri -> {
                    // Handle the returned Uri

                    imgUri = uri;

                    RecipeApi.createRecipe("Butter Chicken",
                            "Delicious butter chicken,",
                            "Indian",
                            Arrays.asList("320 grams of chicken", "teaspoon of salt", "milk", "butter","egg","banana"),
                            Arrays.asList("Preheat pot to 150 degrees", ",marinate chicken for 15 minutes"),
                            269,
                            300,
                            1200,
                            2500,
                            150,
                            0,
                            imgUri,
                            customTaskResult -> {
                                if(customTaskResult.isSuccessFull()){
                                    Toast.makeText(getApplicationContext(), "Sucessfully Created a recipe", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(getApplicationContext(), customTaskResult.errorMessage(), Toast.LENGTH_SHORT).show();

                                }



                            }
                    );
                });


        postImg.setOnClickListener(view -> {
            //open gallery when img clicked
            mGetContent.launch("image/*");



        });









    }



}