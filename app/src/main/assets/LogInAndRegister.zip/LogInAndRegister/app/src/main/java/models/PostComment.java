package models;

import java.util.Map;

public class PostComment {
    String id, postID, postComment;

    public PostComment(String id, String postID, String postComment) {
        this.id = id;
        this.postID = postID;
        this.postComment = postComment;
    }

    public static PostComment fromMap(Map<String,Object> data){
        return new PostComment(
                (String) data.get("id"),
                (String) data.get("post_id"),
                (String) data.get("postComment")
        );
    }


    public String getId() {
        return id;
    }

    public String getPostID() {
        return postID;
    }

    public String getPostComment() {
        return postComment;
    }
}
