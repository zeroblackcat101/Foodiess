package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Recipe {


    private String user_id, recipe_id, name, description, category;
    private List<String> ingredients, steps, foodImages;
    private List<RecipeLike> recipeLikes;
    private List<UserRecipeComment> userRecipeComments;
    private Nutrition nutritionInfo;

    public Recipe(String recipe_id, String user_id, String name, String category, String description, List<String> ingredients, List<String> steps, List<String> foodImages, List<RecipeLike> recipeLikes, List<UserRecipeComment> userRecipeComments, Nutrition nutritionInfo) {
        this.recipe_id = recipe_id;

        this.user_id = user_id;
        this.name = name;
        this.category = category;
        this.description = description;
        this.ingredients = ingredients;
        this.steps = steps;
        this.foodImages = foodImages;
        this.recipeLikes = recipeLikes;
        this.userRecipeComments = userRecipeComments;
        this.nutritionInfo = nutritionInfo;
    }


    public static Recipe fromMap(Map<String, Object> data) {

        return new Recipe(
                (String) data.get("recipe_id")

                , (String) data.get("user_id")
                , (String) data.get("name")
                , (String) data.get("category")
                , (String) data.get("description")
                , (List<String>) data.get("ingredients")
                , (List<String>) data.get("steps")
                , (List<String>) data.get("foodImages")
                //converts list of string to MAP of RecipeLike
                ,
                new ArrayList<RecipeLike>()
//                ((List<Map<String, Object>>) data.get("recipeLikes")).stream().map(e -> RecipeLike.fromMap(e)).collect(Collectors.toList())
                ,
                new ArrayList<UserRecipeComment>()

//                ((List<Map<String, Object>>) data.get("userRecipeComments")).stream().map(e -> UserRecipeComment.fromMap(e)).collect(Collectors.toList())

                , Nutrition.fromMap((Map<String, Object>)data.get("nutritional_info"))
        );


    }

    public String getUser_id() {
        return user_id;
    }

    public String getRecipe_id() {
        return recipe_id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getCategory() {
        return category;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public List<String> getSteps() {
        return steps;
    }

    public List<String> getFoodImages() {
        return foodImages;
    }

    public List<RecipeLike> getRecipeLikes() {
        return recipeLikes;
    }

    public List<UserRecipeComment> getRecipeComments() {
        return userRecipeComments;
    }

    public Nutrition getNutritionInfo() {
        return nutritionInfo;
    }

    @Override
    public String toString() {
        return "Recipe{" +
                "user_id='" + user_id + '\'' +
                ", recipe_id='" + recipe_id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", category='" + category + '\'' +
                ", ingredients=" + ingredients +
                ", steps=" + steps +
                ", foodImages=" + foodImages +
                ", recipeLikes=" + recipeLikes +
                ", userRecipeComments=" + userRecipeComments +
                ", nutritionInfo=" + nutritionInfo +
                '}';
    }
}
