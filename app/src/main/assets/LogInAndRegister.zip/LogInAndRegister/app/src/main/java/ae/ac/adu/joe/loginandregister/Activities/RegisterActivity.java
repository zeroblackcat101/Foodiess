package ae.ac.adu.joe.loginandregister.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import ae.ac.adu.joe.loginandregister.R;
import apis.AuthApi;
import at.favre.lib.crypto.bcrypt.BCrypt;

public class RegisterActivity extends AppCompatActivity {

    public static final String TAG = "TAG";
    TextView alreadyHaveAccount;
    EditText inputEmail, inputPassword, confirmPassword, inputFullName;
    Button btnRegister;
    ProgressBar progressBar;
    FirebaseFirestore fStore;
    String userID;

    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        alreadyHaveAccount = findViewById(R.id.alreadyHaveAccount);

        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        confirmPassword = findViewById(R.id.confirmPassword);
        inputFullName = findViewById(R.id.inputFullName);
        btnRegister = findViewById(R.id.btnRegister);

        progressBar = findViewById(R.id.progressBar2);

        alreadyHaveAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));

            }
        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PerformAuth();
            }
        });
    }

    //method to verify fields and give error if fields are not filled properly

    private void PerformAuth() {
        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();
        String conPassword = confirmPassword.getText().toString().trim();
        String fullName = inputFullName.getText().toString().trim();

        if(fullName.isEmpty()){
            inputFullName.setError("Full Name is required!");
            inputFullName.requestFocus();
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            inputEmail.setError("Please provide valid email!");
            inputEmail.requestFocus();
            return;
        }
        if(password.isEmpty() || password.length() < 6){
            inputPassword.setError("Enter password greater then 6 characters");
            inputPassword.requestFocus();

        }
        if (!password.equals(conPassword)){
            confirmPassword.setError("Password Does Not Match");
            confirmPassword.requestFocus();
        }

        progressBar.setVisibility(View.VISIBLE);


        //Create User with specific email and password

        AuthApi.register(
                fullName,
                email,
                "+97150666666",
                password,
                customTaskResult -> {
                    if(customTaskResult.isSuccessFull()){

                        startActivity(new Intent(getApplicationContext(), MainActivity.class));


                    }else{

                        Toast.makeText(RegisterActivity.this, customTaskResult.errorMessage(), Toast.LENGTH_SHORT).show();
                     progressBar.setVisibility(View.GONE);


                    }
                });

//        mAuth.createUserWithEmailAndPassword(email,password)
//                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if(task.isSuccessful()){
//
//
//
//                            //if creation successful, get user id
//                            Toast.makeText(RegisterActivity.this, "User Created", Toast.LENGTH_SHORT).show();
//                            userID = mAuth.getCurrentUser().getUid();
//                            //create collection in firestore if not already created and add fields
//                            DocumentReference documentReference = fStore.collection("users").document(userID);
//                            Map<String, Object> user = new HashMap<>();
//                            user.put("fullName", fullName);
//                            user.put("email",email);
//                            String hashedPassword = BCrypt.withDefaults().hashToString(12, password.toCharArray());
//
//                            user.put("password",hashedPassword);
//                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
//                                @Override
//                                public void onSuccess(Void unused) {
//                                    Log.d(TAG, "onSuccess: user profile is created for " + userID);
//                                }
//                            });
//                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
//                        } else {
//                            //if account creation is a failure
//                            Toast.makeText(RegisterActivity.this, "Error: ! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
//                            progressBar.setVisibility(View.GONE);
//                        }
//                    }
//                });
    }
}