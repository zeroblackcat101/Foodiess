package models;

import java.util.Map;

public class User {

    private String id, fullName, email, phoneNumber;

    public User(String id, String fullName, String email, String phoneNumber) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public static User fromMap(Map<String, Object> data){

        return new User(
                (String)data.get("id"),
                (String)data.get("fullName"),
                (String)data.get("email"),
                (String)data.get("phoneNumber")

        );


    }

    public String getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
}
