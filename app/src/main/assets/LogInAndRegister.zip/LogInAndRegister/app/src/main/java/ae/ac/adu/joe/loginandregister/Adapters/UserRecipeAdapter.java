package ae.ac.adu.joe.loginandregister.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import ae.ac.adu.joe.loginandregister.Activities.DisplayUserRecipe;
import ae.ac.adu.joe.loginandregister.R;
import models.UserRecipe;

public class UserRecipeAdapter extends RecyclerView.Adapter<UserRecipeAdapter.MyViewHolder> {

    Context mContext;
    List<UserRecipe> rData;

    public UserRecipeAdapter(Context mContext, List<UserRecipe> rData) {
        this.mContext = mContext;
        this.rData = rData;
    }

    @NonNull
    @Override
    public UserRecipeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int index) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.row_recipe_item,parent,false);
        return new UserRecipeAdapter.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UserRecipeAdapter.MyViewHolder holder, int position) {

        holder.row_recipe_title.setText(rData.get(position).getTitle());

//        holder.tvPostDesc.setText(userRecipe.getDescription());
        Glide.with(mContext).load(rData.get(position).getImg_url()).into(holder.row_recipe_img);
//        for(String ingredient : userRecipe.getIngredients()){
//            TextView textView = new TextView(holder.postIngredientLayout.getContext());
//            textView.setText(ingredient);
//            holder.postIngredientLayout.addView(textView);
//
//        }
//        for(int i = 0; i< userRecipe.getSteps().size();i++){
//            String step = userRecipe.getSteps().get(i);
//
//            TextView textView = new TextView(holder.postStepsLayout.getContext());
//            textView.setText((i+1) + ". " + step);
//            holder.postStepsLayout.addView(textView);
//
//        }


    }

    @Override
    public int getItemCount() {
        return rData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView row_recipe_title;
        ImageView row_recipe_img;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            row_recipe_title = itemView.findViewById(R.id.row_recipe_title);
            row_recipe_img = itemView.findViewById(R.id.row_recipe_img);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent displayUserRecipe = new Intent(mContext, DisplayUserRecipe.class);
                    int position = getAdapterPosition();
                    displayUserRecipe.putExtra("user_recipe_id",rData.get(position).getUser_recipe_id());
                    displayUserRecipe.putExtra("title",rData.get(position).getTitle());
                    displayUserRecipe.putExtra("description",rData.get(position).getDescription());
                    displayUserRecipe.putStringArrayListExtra("ingredients", (ArrayList<String>) rData.get(position).getIngredients());
                    displayUserRecipe.putStringArrayListExtra("steps", (ArrayList<String>) rData.get(position).getSteps());
                    displayUserRecipe.putExtra("img_url", rData.get(position).getImg_url());
                    mContext.startActivity(displayUserRecipe);

                }
            });

        }
    }
}
