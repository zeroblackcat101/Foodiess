package ae.ac.adu.joe.loginandregister.Activities;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

import ae.ac.adu.joe.loginandregister.Fragments.AddRecipeFragment;
import ae.ac.adu.joe.loginandregister.Fragments.CommunityFragment;
import ae.ac.adu.joe.loginandregister.R;
import apis.RecipeApi;
import apis.UserRecipeApi;

public class AddRecipe extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Uri imgUri = null;
    Dialog popAddRecipe;
    FloatingActionButton fab;
    Toolbar toolbar;
    FirebaseAuth fAuth;
    FirebaseUser currentUser;
    ImageView popupRecipeImg,popupAddBtn;
    TextView popupTitle,popupDesc;
    LinearLayout ingredientsLinearLayout, rootLinearLayout,stepsLinearLayout;
    ProgressBar popupProgress;
    Button addIngredientBtn,addStepsBtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        fab = findViewById(R.id.fab);


//        categoriesList = findViewById(R.id.popup_category);
//        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.categories,android.R.layout.simple_spinner_item);
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        categoriesList.setAdapter(adapter);
//        categoriesList.setOnItemSelectedListener(this);





        //ini
        fAuth = FirebaseAuth.getInstance();
        currentUser = fAuth.getCurrentUser();

       //ini popup
        iniPopup();
        setUpPopupImgClick();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                popAddRecipe.show();
            }
        });

        //Initialize and Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        //Set Dashboard Selected
        bottomNavigationView.setSelectedItemId(R.id.add);

        //Perform ItemSelectedListener
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.category:
                        startActivity(new Intent(getApplicationContext(), Category.class));
                           overridePendingTransition(0,0);
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(), Home.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.add:
                        return true;
                    case R.id.community:
                        startActivity(new Intent(getApplicationContext(), Community.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.favorites:
                        startActivity(new Intent(getApplicationContext(), Favorites.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

        getSupportFragmentManager().beginTransaction().replace(R.id.container1,new AddRecipeFragment()).commit();

    }

    private void setUpPopupImgClick() {
        ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
                uri -> {
                    // Handle the returned Uri
                    popupRecipeImg.setImageURI(uri);
                    imgUri = uri;

                });


        popupRecipeImg.setOnClickListener(view -> {
            //open gallery when img clicked
            mGetContent.launch("image/*");

        });
    }


    private void iniPopup() {
        popAddRecipe = new Dialog(this);
        popAddRecipe.setContentView(R.layout.popup_add_recipe);
        popAddRecipe.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popAddRecipe.getWindow().setLayout(Toolbar.LayoutParams.MATCH_PARENT,Toolbar.LayoutParams.WRAP_CONTENT);
        popAddRecipe.getWindow().getAttributes().gravity = Gravity.TOP;


        //ini popup widgets
        popupRecipeImg = popAddRecipe.findViewById(R.id.popup_recipe_img);
        popupTitle = popAddRecipe.findViewById(R.id.popup_recipe_title);
        popupDesc = popAddRecipe.findViewById(R.id.popup_recipe_description);
//        popupNutrition = popAddRecipe.findViewById(R.id.popup_recipe_nutrition);
//        popupIngredients = popAddRecipe.findViewById(R.id.popup_ingredients);
        ingredientsLinearLayout = popAddRecipe.findViewById(R.id.ingredientLinearLayout);
        stepsLinearLayout = popAddRecipe.findViewById(R.id.stepsLinearLayout);

//        popupSteps = popAddRecipe.findViewById(R.id.popup_recipe_steps);
        popupProgress = popAddRecipe.findViewById(R.id.popup_progressBar);
        popupAddBtn = popAddRecipe.findViewById(R.id.popup_add);
        addIngredientBtn = popAddRecipe.findViewById(R.id.addIngredientBtn);
        addStepsBtn = popAddRecipe.findViewById(R.id.addStepsBtn);
        rootLinearLayout = popAddRecipe.findViewById(R.id.rootLinearLayout);

        addIngredientBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textField = new EditText(ingredientsLinearLayout.getContext());
                textField.setMinimumWidth((int) Math.round(rootLinearLayout.getWidth()*0.5));
                ingredientsLinearLayout.addView(textField);
            }
        });

        addStepsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText textField = new EditText(stepsLinearLayout.getContext());
                textField.setMinimumWidth((int) Math.round(rootLinearLayout.getWidth()*0.5));
               stepsLinearLayout.addView(textField);
            }
        });



        // add post click listener
        popupAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String recipeName = popupTitle.getText().toString().trim();
                String recipeDescription = popupDesc.getText().toString().trim();


                popupAddBtn.setVisibility(View.INVISIBLE);
                popupProgress.setVisibility(View.VISIBLE);
                List<String> ingredients = new ArrayList<String>();

                for (int i = 0; i < ingredientsLinearLayout.getChildCount(); i++) {
                    View myView = ingredientsLinearLayout.getChildAt(i);
                    if (myView instanceof EditText) {
                        EditText editText = (EditText) myView;

                        ingredients.add(editText.getText().toString());


                    }
                }

                List<String> steps = new ArrayList<String>();

                for (int i = 0; i < stepsLinearLayout.getChildCount(); i++) {
                    View stepView = stepsLinearLayout.getChildAt(i);
                    if (stepView instanceof EditText) {
                        EditText editText = (EditText) stepView;

                        steps.add(editText.getText().toString());


                    }
                }

//                System.out.println(ingredients);


                //check all input fields and image
                if (!recipeName.isEmpty()
                        && !recipeDescription.isEmpty()
                        && !ingredients.isEmpty()
                        && !steps.isEmpty()
                        && imgUri != null) {
                    UserRecipeApi.createUserRecipes(recipeName, recipeDescription, ingredients, steps, imgUri, customTaskResult -> {
                        if (customTaskResult.isSuccessFull()) {

                            Toast.makeText(AddRecipe.this, "Recipe Created", Toast.LENGTH_SHORT).show();
                            popupProgress.setVisibility(View.INVISIBLE);
                            popupAddBtn.setVisibility(View.VISIBLE);
                            popAddRecipe.dismiss();

                        } else {

                            Toast.makeText(AddRecipe.this, customTaskResult.errorMessage(), Toast.LENGTH_LONG).show();
                            popupAddBtn.setVisibility(View.VISIBLE);


                        }

                    });

                } else {
                    Toast.makeText(AddRecipe.this, "Please verify all input fields and post image", Toast.LENGTH_LONG).show();
                    popupAddBtn.setVisibility(View.VISIBLE);
                    popupProgress.setVisibility(View.INVISIBLE);

                }
            }
        });

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}