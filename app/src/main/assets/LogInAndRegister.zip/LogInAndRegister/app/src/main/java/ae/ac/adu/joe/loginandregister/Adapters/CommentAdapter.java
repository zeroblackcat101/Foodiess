package ae.ac.adu.joe.loginandregister.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import ae.ac.adu.joe.loginandregister.R;
import models.UserRecipeComment;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder>{

    private Context mContext;
    private List<UserRecipeComment> cData;

    public CommentAdapter(Context mContext, List<UserRecipeComment> cData) {
        this.mContext = mContext;
        this.cData = cData;
    }

    @NonNull
    @Override
    public CommentAdapter.CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(mContext).inflate(R.layout.row_comment,parent,false);
        return new CommentViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull CommentAdapter.CommentViewHolder holder, int position) {
        holder.tv_content.setText(cData.get(position).getRecipeComment());
    }

    @Override
    public int getItemCount() {
        return cData.size();
    }

    public class CommentViewHolder extends RecyclerView.ViewHolder {
        TextView tv_content;
        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_content = itemView.findViewById(R.id.comment_content);
        }
    }
}
