package ae.ac.adu.joe.loginandregister.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Arrays;
import java.util.List;

import ae.ac.adu.joe.loginandregister.R;
import apis.AuthApi;
import apis.RecipeApi;
import models.Recipe;
import models.User;
import utils.CustomTask;
import utils.CustomTaskResult;

public class MainActivity extends AppCompatActivity {


    TextView createNewAccount;
    EditText inputEmail, inputPassword;
    Button btnLogin;
    FirebaseAuth fAuth;
    ProgressBar progressBar;
    Button testBtn;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);






        testBtn = findViewById(R.id.testBtn);
        testBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent,3);


            }
        });



//RecipeApi.getAllRecipes(new CustomTask<List<Recipe>>() {
//    @Override
//    public void complete(CustomTaskResult<List<Recipe>> customTaskResult) {
//
//        if(customTaskResult.isSuccessFull()){
//            Log.e("recipelists",customTaskResult.getData().toString());
//
//        }else{}
//
//    }
//});

        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        fAuth = FirebaseAuth.getInstance();
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);


        createNewAccount = findViewById(R.id.createNewAccount);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();

                if (email.isEmpty()) {
                    inputEmail.setError("Email is Required.");
                    inputEmail.requestFocus();
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    inputEmail.setError("Please provide valid email!");
                    inputEmail.requestFocus();
                    return;
                }

                if (password.isEmpty() || password.length() < 6) {
                    inputPassword.setError("Enter password greater then 6 characters");
                    inputPassword.requestFocus();
                    return;

                }
                progressBar.setVisibility(View.VISIBLE);

                AuthApi.login(getApplicationContext(),email, password, customTaskResult -> {

                    if (customTaskResult.isSuccessFull()) {

                        Toast.makeText(MainActivity.this, "Logged in Successfully as " + customTaskResult.getData().getFullName(), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), Home.class));
                    } else {

                        Toast.makeText(MainActivity.this, customTaskResult.errorMessage(), Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);


                    }

                });

//                fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(task -> {
//                    if(task.isSuccessful()){
//                        Toast.makeText(MainActivity.this, "Logged in Successfully", Toast.LENGTH_SHORT).show();
//                        startActivity(new Intent(getApplicationContext(), Home.class));
//                    }else {
//                        Toast.makeText(MainActivity.this, "Error ! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
//                        progressBar.setVisibility(View.GONE);
//                    }
//
//                });
            }
        });


        createNewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });


    }
    @Override
    protected void onStart() {
        super.onStart();




    }



//    @Override
//    protected void onActivityResult(
//            int requestCode, int resultCode, final Intent data) {
//
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == 3 && resultCode == RESULT_OK && data != null) {
//            Uri selectedImage = data.getData();
//
//            ///showing loading indicator
//        RecipeApi.createRecipe("Butter Chicken",
//                "Delicious butter chicken,",
//                Arrays.asList("320 grams of chicken", "teaspoon of salt", "milk", "butter"),
//                Arrays.asList("Preheat pot to 150 degrees", ",marinate chicken for 15 minutes"),
//                269,
//                300,
//                1200,
//                2500,
//                150,
//                0,
//                selectedImage,
//                new CustomTask<Void>() {
//                    @Override
//                    public void complete(CustomTaskResult<Void> customTaskResult) {
//                        if(customTaskResult.isSuccessFull()){
//                            Toast.makeText(MainActivity.this, "Sucessfully Created a recipe", Toast.LENGTH_SHORT).show();
//                            progressBar.setVisibility(View.GONE);
//                        }else{
//                            Toast.makeText(MainActivity.this, customTaskResult.errorMessage(), Toast.LENGTH_SHORT).show();
//                            progressBar.setVisibility(View.GONE);
//
//                        }

                        //remove loading indicator


//                    }
//                }
//        );
//
//
//        }
//    }
//     navigationView.setNavigationItemSelectedListener(item -> {
//        if (item.getItemId() == R.id.nav_sign_out){
//            AlertDialog.Builder builder = new AlertDialog.Builder(DriverHomeActivity.this);
//            builder.setTitle("Sign out")
//                    .setMessage("Do you really want to sign out")
//                    .setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss())
//                    .setPositiveButton("SIGN OUT", (dialog, which) -> {
//                        FirebaseAuth.getInstance().signOut();
//                        Intent intent = new Intent(DriverHomeActivity.this, SplashScreenActivity.class);
//                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
//                        startActivity(intent);
//                        finish();
//                    })
//                    .setCancelable(false);
//            AlertDialog dialog = builder.create();
//            dialog.setOnShowListener(dialog1 -> {
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
//                        .setTextColor(ContextCompat.getColor(DriverHomeActivity.this,android.R.color.holo_red_dark));
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
//                        .setTextColor(ContextCompat.getColor(DriverHomeActivity.this,R.color.black));
//
//            });
//
//            dialog.show();
//
//        }
//        return true;
//    });
}
