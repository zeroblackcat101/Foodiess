package ae.ac.adu.joe.loginandregister.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import ae.ac.adu.joe.loginandregister.Adapters.GridAdapter;
import ae.ac.adu.joe.loginandregister.Adapters.RecipeAdapter;
import ae.ac.adu.joe.loginandregister.R;
import ae.ac.adu.joe.loginandregister.databinding.ActivityCategoryBinding;
import models.Recipe;

public class Category extends AppCompatActivity {
//    ActivityCategoryBinding binding;


//    int[] categoryImage = {R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d,R.drawable.e,R.drawable.f};
    SearchView searchView;
    RecyclerView searchRecyclerView;
   private  FirebaseFirestore fStore = FirebaseFirestore.getInstance();
    private CollectionReference recipeRef = fStore.collection("recipes");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        searchRecyclerView = findViewById(R.id.searchRecyclerView);
        searchRecyclerView.setHasFixedSize(true);
        searchRecyclerView.setLayoutManager(new LinearLayoutManager(this));

//        binding = ActivityCategoryBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//
//
//        String[] categoryName = {"Asian","Italian","Mexican","Seafood","Casual","Breakfast"};
//        GridAdapter gridAdapter = new GridAdapter(Category.this,categoryName, categoryImage);
//        binding.gridView.setAdapter(gridAdapter);
//
//        binding.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
//                Toast.makeText(Category.this,"You clicked on " + categoryName[position],Toast.LENGTH_SHORT).show();
//            }
//        });

        searchView = findViewById(R.id.searchView);

//        recipeList = new ArrayList<Recipe>();
//        recipeAdapter =
//                new RecipeAdapter(Category.this,recipeList);
//
//        searchRecyclerView.setAdapter(recipeAdapter);

//        CollectionReference recipeRef = fStore.collection("recipes");
//        recipeRef.whereArrayContainsAny("ingredients", Collections.singletonList(s.toString())).get().addOnCompleteListener(task -> {
//            List<Recipe> filteredRecipes = new ArrayList<Recipe>();
//            if (task.isSuccessful()) {
//                for (QueryDocumentSnapshot document : task.getResult()) {
//
//                    filteredRecipes.add(Recipe.fromMap(document.getData()));
//                    Log.e("TAG", document.getId() + " => " + document.getData());
//
//                }
//
//                this.recipeList.clear();
//                this.recipeList.addAll(filteredRecipes);
//                recipeAdapter.notifyDataSetChanged();
//
//            } else {
//                Log.e("TAG", "Error getting documents: ", task.getException());
//            }
//
//        });
        //remove cursor from searchview


        searchView.clearFocus();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Log.i("testmode onQueryTextSubmit",s);
                filterRecipes(s);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                //ignore

                return false;
            }
        });

//        searchView.addTextChangedListener(new TextWatcher() {
//
//            @Override
//            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
//               String searchText = searchView.getText().toString();
//               searchInFireStore(searchText);
//            Log.i("textchange", "onTextChanged");
//
////                if(s.toString().length() == 0) {
////                    q = fStore.collection("recipes");
////                } else{
////                    q = recipeRef.orderBy("name").startAt(s.toString().trim()).endAt(s.toString().trim() + "\uf8ff");
////                    showAdapter(q);
////                }
////
////                recipeAdapter.notifyDataSetChanged();
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                Log.i("textchange", "afterTextChanged");
//
////                Log.d("SearchBar","Searchbar has changed to: " + s.toString());
////                recipeRef.whereEqualTo("ingredients", (s.toString())).get().addOnCompleteListener(task -> {
////                    List<Recipe> filteredRecipes = new ArrayList<Recipe>();
////                    if (task.isSuccessful()) {
////                        for (QueryDocumentSnapshot document : task.getResult()) {
////
////                            filteredRecipes.add(Recipe.fromMap(document.getData()));
////                            Log.e("TAG", document.getId() + " => " + document.getData());
////
////                        }
////
////                        recipeList.clear();
////                        recipeList.addAll(filteredRecipes);
////                        recipeAdapter.notifyDataSetChanged();
////
////                    } else {
////                        Log.e("TAG", "Error getting documents: ", task.getException());
////                    }
////
////                });
//            }
//        });


        //Initialize and Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        //Set Dashboard Selected
        bottomNavigationView.setSelectedItemId(R.id.category);

        //Perform ItemSelectedListener
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.category:
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(), Home.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.add:
                        startActivity(new Intent(getApplicationContext(), AddRecipe.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.community:
                        startActivity(new Intent(getApplicationContext(),Community.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.favorites:
                        startActivity(new Intent(getApplicationContext(),Favorites.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
    }

//    private void searchInFireStore(String searchText) {
//        //search query
//       q= fStore.collection("recipes").orderBy("name")
//                .startAt(searchText).endAt(searchText +  "\uf8ff");
//       showAdapter(q);
//       recipeAdapter.notifyDataSetChanged();
//    }

//    private void showAdapter(Query q1) {
//        q1.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                List<Recipe> recipeList = new ArrayList<Recipe>();
//                if (task.isSuccessful()) {
//                    for (QueryDocumentSnapshot document : task.getResult()) {
//
////                       ingredients.add(Recipe.fromMap(document.getData()));
//                        Log.e("TAG", document.getId() + " => " + document.getData());
//
//                    }
//
//                 recipeAdapter = new RecipeAdapter(Category.this,recipeList);
//                    searchRecyclerView.setAdapter(recipeAdapter);
//                }
//            }
//        });
//
//    }

    private void filterRecipes(String searchText){
        recipeRef.whereArrayContains("ingredients",searchText).get().addOnCompleteListener(task -> {

            if(task.isSuccessful()){


                List<Recipe> recipes = task.getResult().getDocuments().stream().map(e->Recipe.fromMap(e.getData())).collect(Collectors.toList());


                RecipeAdapter recipeAdapter = new RecipeAdapter(Category.this,recipes);
                    searchRecyclerView.setAdapter(recipeAdapter);


            }else{}

        });
    }
}