package ae.ac.adu.joe.loginandregister.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;

import ae.ac.adu.joe.loginandregister.R;
import apis.AuthApi;
import apis.RecipeApi;
import models.Recipe;
import models.User;
import utils.CustomTask;
import utils.CustomTaskResult;
import utils.JsonUtil;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.opencv.android.OpenCVLoader;


public class Home extends AppCompatActivity {
    static {
        if(OpenCVLoader.initDebug()){
            Log.i("Home: ","Opencv is loaded");
        }
        else {
            Log.i("Home: ","Opencv failed to load");
        }
    }

    Button signOutBtn, scanBtn;
    FirebaseFirestore fStore = FirebaseFirestore.getInstance();
    CollectionReference recipeRef = fStore.collection("recipes");
    public String getJsonFromAssets() {
        String jsonString = null;
        try {

            InputStream is = getApplicationContext().getAssets().open("objects.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return jsonString;
    }

//    String jsonFileString = getJsonFromAssets();
//
//        Log.i("data", jsonFileString);
//        Gson gson = new Gson();
//        Type type = new TypeToken<HashMap<String,Object>>() { }.getType();
//       HashMap<String, Object> jsonMap = gson.fromJson(jsonFileString, type);
//        for (Map.Entry<String,Object> entry: jsonMap.entrySet()) {
//            Log.i("data", "Entries: " + entry );
//        }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        signOutBtn = findViewById(R.id.signOutBtn);
        scanBtn = findViewById(R.id.scanButton);
        scanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),CameraActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });



//        Log.i("data", jsonFileString);
//        Gson gson = new Gson();
//        Type type = new TypeToken<HashMap<String,Object>>() { }.getType();
//       HashMap<String, Object> jsonMap = gson.fromJson(jsonFileString, type);
//        for (Map.Entry<String,Object> entry: jsonMap.entrySet()) {
//            Log.i("data", "Entries: " + entry );
//        }
        String jsonFileString = getJsonFromAssets();


        ObjectMapper mapper = new ObjectMapper();
        try
        {
            //Convert Map to JSON

            List<Map<String, Object>> list = mapper.readValue(jsonFileString , new TypeReference<List<Map<String, Object>>>(){});
            //Print JSON output

            System.out.println(list);

            List<String> ingredients = list.stream().map(e->e.get("name").toString()).collect(Collectors.toList());


                    recipeRef.whereArrayContainsAny("ingredients",ingredients).get().addOnCompleteListener(task -> {
                        List<Recipe> filteredRecipes = new ArrayList<Recipe>();
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {

                                filteredRecipes.add(Recipe.fromMap(document.getData()));
                                Log.e("TAG", document.getId() + " => " + document.getData());

                            }

                        } else {
                            Log.e("TAG", "Error getting documents: ", task.getException());
                        }

                        });







        }
        catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }




        //Initialize and Assign Variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        //Set Dashboard Selected
        bottomNavigationView.setSelectedItemId(R.id.home);

        //temporary sign out method, will be changed
        signOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                builder.setTitle("Sign out")
                        .setMessage("Do you really want to sign out")
                        .setNegativeButton("CANCEL", (dialog, which) -> dialog.dismiss())
                        .setPositiveButton("SIGN OUT", (dialog, which) -> {
                            AuthApi.logout(getApplicationContext(), customTaskResult -> {
                                Intent intent = new Intent(Home.this, MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK );
                                startActivity(intent);
                                finish();

                            });

                        })
                        .setCancelable(false);
                AlertDialog dialog = builder.create();
                dialog.setOnShowListener(dialog1 -> {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            .setTextColor(ContextCompat.getColor(Home.this,android.R.color.holo_red_dark));
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                            .setTextColor(ContextCompat.getColor(Home.this,R.color.black));

                });

                dialog.show();

            }
        });

        //Perform ItemSelectedListener
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.category:
                        startActivity(new Intent(getApplicationContext(), Category.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home:
                        return true;
                    case R.id.add:
                        startActivity(new Intent(getApplicationContext(), AddRecipe.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.community:
                        startActivity(new Intent(getApplicationContext(), Community.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.favorites:
                        startActivity(new Intent(getApplicationContext(), Favorites.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
    }
}