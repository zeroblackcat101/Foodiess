package ae.ac.adu.joe.loginandregister.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import ae.ac.adu.joe.loginandregister.R;

public class Favorites extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
    }
}