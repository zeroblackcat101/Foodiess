package ae.ac.adu.joe.loginandregister.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.api.Distribution;

import org.w3c.dom.Text;

import java.util.List;

import ae.ac.adu.joe.loginandregister.R;
import models.Nutrition;
import models.Recipe;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.MyViewHolder> {

    Context context;
    List<Recipe> rData;

    public RecipeAdapter(Context context, List<Recipe> rData) {
        this.context = context;
        this.rData = rData;
    }

    @NonNull
    @Override
    public RecipeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int index) {
        View v = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecipeAdapter.MyViewHolder holder, int position) {

        Recipe recipe = rData.get(position);
        holder.tvTitle.setText(recipe.getName());
        holder.tvDesc.setText(recipe.getDescription());

        for(String ingredient : recipe.getIngredients()){
            TextView textView = new TextView(holder.ingredientLinearLayout.getContext());
            textView.setText(ingredient);
            holder.ingredientLinearLayout.addView(textView);

        }
        for(int i = 0; i< recipe.getSteps().size();i++){
            String step = recipe.getSteps().get(i);

            TextView textView = new TextView(holder.stepsLinearLayout.getContext());
            textView.setText((i+1) + ". " + step);
            holder.stepsLinearLayout.addView(textView);

        }

        Nutrition nutrition = recipe.getNutritionInfo();

        LinearLayout carbLinearLayout = new LinearLayout(holder.nutritionLinearLayout.getContext());
        carbLinearLayout.setOrientation(LinearLayout.HORIZONTAL);


        LinearLayout caloriesLinearLayout = new LinearLayout(holder.nutritionLinearLayout.getContext());
        caloriesLinearLayout.setOrientation(LinearLayout.HORIZONTAL);


        LinearLayout sodiumLinearLayout = new LinearLayout(holder.nutritionLinearLayout.getContext());
        sodiumLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout proteinLinearLayout = new LinearLayout(holder.nutritionLinearLayout.getContext());
        proteinLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout fatLinearLayout = new LinearLayout(holder.nutritionLinearLayout.getContext());
        fatLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout cholLinearLayout = new LinearLayout(holder.nutritionLinearLayout.getContext());
        cholLinearLayout.setOrientation(LinearLayout.HORIZONTAL);



        TextView tvCarbsLabel = new TextView(carbLinearLayout.getContext());
        TextView tvCaloriesLabel = new TextView(caloriesLinearLayout.getContext());
        TextView tvSodiumLabel = new TextView(sodiumLinearLayout.getContext());
        TextView tvProteinLabel = new TextView(proteinLinearLayout.getContext());
        TextView tvFatLabel = new TextView(fatLinearLayout.getContext());
        TextView tvCholLabel = new TextView(cholLinearLayout.getContext());

        TextView tvCarbs = new TextView(carbLinearLayout.getContext());
        TextView tvCalories = new TextView(caloriesLinearLayout.getContext());
        TextView tvSodium = new TextView(sodiumLinearLayout.getContext());
        TextView tvProtein = new TextView(proteinLinearLayout.getContext());
        TextView tvFat = new TextView(fatLinearLayout.getContext());
        TextView tvChol = new TextView(cholLinearLayout.getContext());



        tvCarbsLabel.setText("Carbohydrates: ");
        tvCaloriesLabel.setText("Calories: ");
        tvSodiumLabel.setText( "Sodium: ");
        tvProteinLabel.setText("Protein: ");
        tvFatLabel.setText("Fat: ");
        tvCholLabel.setText( "Cholesterol: ");


        tvCarbs.setText( Long.toString(nutrition.getCarbohydrates()));
        tvCalories.setText( Long.toString(nutrition.getCalories()));
        tvSodium.setText( Long.toString(nutrition.getSodium()));
        tvProtein.setText( Long.toString(nutrition.getProtein()));
        tvFat.setText( Long.toString(nutrition.getFat()));
        tvChol.setText( Long.toString(nutrition.getCholesterol()));




        carbLinearLayout.addView(tvCarbsLabel);
        caloriesLinearLayout.addView(tvCaloriesLabel);
        sodiumLinearLayout.addView(tvSodiumLabel);
        proteinLinearLayout.addView(tvProteinLabel);
        fatLinearLayout.addView(tvFatLabel);
        cholLinearLayout.addView(tvCholLabel);

       carbLinearLayout.addView(tvCarbs);
        caloriesLinearLayout.addView(tvCalories);
        sodiumLinearLayout.addView(tvSodium);
        proteinLinearLayout.addView(tvProtein);
       fatLinearLayout.addView(tvFat);
        cholLinearLayout.addView(tvChol);



        holder.nutritionLinearLayout.addView(carbLinearLayout);
        holder.nutritionLinearLayout.addView(caloriesLinearLayout);
        holder.nutritionLinearLayout.addView(sodiumLinearLayout);
        holder.nutritionLinearLayout.addView(proteinLinearLayout);
        holder.nutritionLinearLayout.addView(fatLinearLayout);
        holder.nutritionLinearLayout.addView(cholLinearLayout);





    }

    @Override
    public int getItemCount() {
        return rData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tvTitle,tvDesc;
        LinearLayout ingredientLinearLayout, stepsLinearLayout, nutritionLinearLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            ingredientLinearLayout = itemView.findViewById(R.id.ingredientLayout);
            stepsLinearLayout = itemView.findViewById(R.id.stepsLayout);
            nutritionLinearLayout = itemView.findViewById(R.id.nutritionLayout);



            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDesc = itemView.findViewById(R.id.tvDesc);

        }
    }



}
