package ae.ac.adu.joe.loginandregister.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import ae.ac.adu.joe.loginandregister.Adapters.PostAdapter;
import ae.ac.adu.joe.loginandregister.Adapters.RecipeAdapter;
import ae.ac.adu.joe.loginandregister.R;
import models.Post;
import models.Recipe;

public class DisplayRecipe extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Recipe> recipeList;
    RecipeAdapter recipeAdapter;
    FirebaseFirestore fStore;
    ProgressDialog progressDialog;
    public String getJsonFromAssets() {
        String jsonString = null;
        try {
            InputStream is = getApplicationContext().getAssets().open("objects.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return jsonString;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_recipe);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching Data... ");
        progressDialog.show();

        recyclerView = findViewById(R.id.displayRecipe);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fStore = FirebaseFirestore.getInstance();
        recipeList = new ArrayList<Recipe>();
        recipeAdapter =
        new RecipeAdapter(DisplayRecipe.this,recipeList);

        recyclerView.setAdapter(recipeAdapter);

        EventChangeListener();


    }

    private void EventChangeListener() {


        String jsonFileString = getJsonFromAssets();


        ObjectMapper mapper = new ObjectMapper();
        try
        {
            CollectionReference recipeRef = fStore.collection("recipes");

            //Convert Map to JSON

            List<Map<String, Object>> list = mapper.readValue(jsonFileString , new TypeReference<List<Map<String, Object>>>(){});
            //Print JSON output

            System.out.println(list);

            List<String> ingredients = list.stream().map(e->e.get("name").toString()).collect(Collectors.toList());


            recipeRef.whereArrayContainsAny("ingredients",ingredients).get().addOnCompleteListener(task -> {
                List<Recipe> filteredRecipes = new ArrayList<Recipe>();
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {

                        filteredRecipes.add(Recipe.fromMap(document.getData()));
                        Log.e("TAG", document.getId() + " => " + document.getData());

                    }

                    this.recipeList.clear();
                    this.recipeList.addAll(filteredRecipes);
                    recipeAdapter.notifyDataSetChanged();
                    if (progressDialog.isShowing())
                        progressDialog.dismiss();

                } else {
                    Log.e("TAG", "Error getting documents: ", task.getException());
                }

            });







        }
        catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }




//        fStore.collection("recipes").orderBy("name",Query.Direction.ASCENDING).addSnapshotListener((value, error) -> {
//            if(error != null){
//                if (progressDialog.isShowing())
//                    progressDialog.dismiss();
//                Log.e("Firestore error",error.getMessage());
//                return;
//            }
//            for (DocumentChange dc : value.getDocumentChanges()){
//                if(dc.getType() == DocumentChange.Type.ADDED){
//                    recipeList.add(Recipe.fromMap(dc.getDocument().getData()));
//                }
//                recipeAdapter.notifyDataSetChanged();
//                if (progressDialog.isShowing())
//                    progressDialog.dismiss();
//            }
//        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();


    }
}